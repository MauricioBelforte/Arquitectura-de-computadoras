/*
 * Arquitectura de Computadoras
 * Facultad de Ingenier�a
 * UNPSJB - Trelew
 *
 * Ejemplo de interrupciones de un timer.
 * Prop�sito del ejemplo: Generar una interrupci�n del timer1 cada 100ms.
 */
#include "xc.h"

void __attribute__((interrupt, auto_psv)) _T1Interrupt( void ) {
    // Este c�digo se ejecuta cada 100 ms.
    IFS0bits.T1IF = 0;
}

void config(void) {
        //Configurar Timer1
        T1CONbits.TON = 0;
        T1CONbits.TCS = 0;
        T1CONbits.TCKPS = 2; // 1:64
        TMR1 = 0;
        PR1 = 62500;
        //Configurar Interrupci�n.
        IPC0bits.T1IP = 1; // Prioridad 1
        IFS0bits.T1IF = 0;
        IEC0bits.T1IE = 1;
        T1CONbits.TON = 1; // Start!
 }

int main(void) {
    config();
    while(1) {
        Nop();
        Nop();
        Nop();
    }
}
