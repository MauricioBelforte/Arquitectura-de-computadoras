/*
 * File:   main.c
 * Author: Luciano Serruya Aloisi
 *
 * Created on May 14, 2019, 6:27 PM
 */


#include "xc.h"
#include "config.h"

void __attribute__((interrupt, auto_psv)) _DMA0Interrupt(void) {
    /* Rutina de atenci�n para la interrupci�n del DMA */
    IFS0bits.DMA0IF = 0;
}


int main(void) {
    config();
    while(1) {
        /*
         * Agregar la l�gica necesaria
         * Agregar las variables que considere necesarias
         */
    }
    return 0;
}
